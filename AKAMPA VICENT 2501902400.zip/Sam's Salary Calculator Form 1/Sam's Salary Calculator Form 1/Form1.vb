﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim salary As Decimal
        Dim dependents As Integer
        Dim fees As Decimal

        'Validate user inputs
        If Not Decimal.TryParse(txtSalary.Text, salary) OrElse
           Not Integer.TryParse(txtDependents.Text, dependents) OrElse
           Not Decimal.TryParse(txtFees.Text, fees) Then

            MessageBox.Show("Please enter valid numbers.",
                            "Input Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            Exit Sub

        End If

        If salary < 0 OrElse dependents < 0 OrElse fees < 0 Then
            MessageBox.Show("Values cannot be negative.",
                            "Input Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            Exit Sub
        End If

        'Calculate total school fees
        Dim totalExpenses As Decimal = dependents * fees

        'Calculate take-home balance after school fees
        Dim takeHome As Decimal = salary - totalExpenses

        'Calculate salary deductions
        Dim nssf As Decimal = salary * 0.1D
        Dim paye As Decimal = salary * 0.09D
        Dim sacco As Decimal = salary * 0.05D

        'Calculate balance after salary deductions
        Dim totalDeductions As Decimal = nssf + paye + sacco
        Dim finalBalance As Decimal = salary - totalDeductions

        'Display the results
        txtTotalExpenses.Text = totalExpenses.ToString("N0")
        txtTakeHome.Text = takeHome.ToString("N0")
        txtNSSF.Text = nssf.ToString("N0")
        txtPAYE.Text = paye.ToString("N0")
        txtSACCO.Text = sacco.ToString("N0")
        txtFinalBalance.Text = finalBalance.ToString("N0")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtSalary.Clear()
        txtDependents.Clear()
        txtFees.Clear()

        txtTotalExpenses.Clear()
        txtTakeHome.Clear()
        txtNSSF.Clear()
        txtPAYE.Clear()
        txtSACCO.Clear()
        txtFinalBalance.Clear()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Dim answer As DialogResult

        answer = MessageBox.Show("Are you sure you want to exit?",
                                 "Confirm Exit",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question)

        If answer = DialogResult.Yes Then
            Me.Close()
        End If

    End Sub

End Class
